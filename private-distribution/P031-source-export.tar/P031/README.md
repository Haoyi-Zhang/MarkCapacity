# Observational Capacity of Behavior-Preserving Code Watermarks

论文目标：TOPLAS。

- `paper/`：论文源稿、参考文献、模板、PDF及补充材料。
- `artifact/`：代码、证明、复现输入、结果、依赖与许可证；独立代码仓库使用此目录的内容。

主稿源文件：`paper/main.tex`。

主稿PDF：`paper/main.pdf`。

构建与复现命令见相应目录的 README 或构建脚本。
代码与外部材料的许可分别见artifact及paper目录内的许可和来源说明。

## 当前作者与合作安排

当前实名作者顺序：Haoyi Zhang → Huaijin Ran → Xunzhu Tang。

没有新增共同贡献声明。

未确认的老师、刘洋、孙宇强、俞炯弛均不进入当前署名。合作或联系安排不自动形成作者身份。

合作／联系安排：05_Xunzhu Tang。具体作者信息见 `paper/current-authors.json`。

当前公开代码仓库：[watermark-observational-capacity-artifact](https://github.com/Haoyi-Zhang/MarkCapacity-code)；已验证公开读取，论文 Code Availability 使用这个真实地址。
