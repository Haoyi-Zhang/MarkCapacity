#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

# Freeze PDF metadata timestamps so identical sources yield identical bytes.
export SOURCE_DATE_EPOCH=1784376000
export FORCE_SOURCE_DATE=1
export TZ=UTC

# Some distributions retain the real BibTeX binary as bibtex.original while a
# wrapper symlink is unavailable. Use the normal command when possible and a
# temporary PATH shim only for that packaging edge case.
if command -v bibtex >/dev/null 2>&1 && bibtex --version >/dev/null 2>&1; then
  latexmk -xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
elif command -v bibtex.original >/dev/null 2>&1; then
  shim="$(mktemp -d)"
  trap 'rm -rf "$shim"' EXIT
  ln -s "$(command -v bibtex.original)" "$shim/bibtex"
  PATH="$shim:$PATH" latexmk -xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
else
  printf '%s\n' 'BibTeX is required but no working bibtex executable was found.' >&2
  exit 127
fi
