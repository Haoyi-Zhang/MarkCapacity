# Submission checklist

The scientific package is internally complete, but the author list is not.

Before any upload, the authors must:

- replace the three reserved positions with the final author records or remove the reservation;
- supply Xunzhu Tang's exact city/campus and ORCID if applicable;
- confirm the corresponding author;
- obtain all authors' approval of order, affiliations, contribution, and accountability;
- verify the live TOPLAS anonymity and file-format instructions;
- disclose conflicts and every prior thesis, workshop, conference, journal, or preprint version accurately;
- prepare the required cover letter and portal metadata;
- comply with the current ACM authorship, artificial-intelligence, rights, and open-access policies;
- obtain an independent artifact-only review.

Do not submit the current named PDF as a final author list while the last three positions are unresolved.
