# TOPLAS-19 research lock and evidence plan

Date: 2026-09-26

## Research question

For a fixed behavioral preservation contract, detector, attack family, source-dependent access relation, and nonempty message alphabet, determine exactly when every supported source can encode every message while preserving behavior and retaining the message under the declared operational obligations.

## Locked scientific scope

The paper studies semantic existence boundaries. It does not claim a practical embedding algorithm, a distribution-preserving sampler, statistical concealment, cryptographic unremovability, ownership adjudication, or efficient contextual-equivalence decision procedures.

## Main proof chain

1. Detector indistinguishability and attack obligations generate an operational equivalence.
2. Every admissible decoder factors through the operational quotient.
3. Under refinement and class-complete access, exact capacity is the minimum quotient width of a behavior class.
4. In crossing and source-dependent cases, exact feasibility is global polychromatic coverage of every source constraint; refinement is sufficient for local counting, not generally necessary.
5. Fixed terminating-language constructions realize arbitrary finite nonempty-edge incidence patterns.
6. Complexity, compactness, randomized recovery, products, recognition, and insertion are classified under their stated quantifiers.

## Input and empty-object contract

The support-capacity proposition assumes nonempty support. Every required access row, and every required directed preservation row, must be explicitly present. Missing rows are malformed input. An explicit empty row is a valid edge but admits no nonempty message alphabet. The reported capacity convention is: 0 means no scheme; 1 means one fixed message and zero owner-selected bits.

## Evidence contract

The frozen manuscript contains 52 formal statements, four native vector figures, nine tables, 68 scholarly bibliography records, and 99 single-key sentence-local citations. The self-contained scientific package has 56 scientific tests passing. The full project has 8 package-integrity tests, for 64 total checks in a complete checkout.

The main statements and proofs remain in the 48-page paper. The scientific checker validates finite analogues, explicit counterexamples, monotonicity directions, direct source/output witnesses, representation invariances, missing-versus-empty-row boundaries, and deterministic stress cases. Package checks validate paper, citation, statement-location, manifest, and PDF surfaces and require explicitly documented external tools. Finite computation is regression evidence and executable correspondence, not a replacement for arbitrary-set proofs.

## Release gates

The internal package must preserve separate scientific and package entry points, pass 56 scientific plus 8 integrity checks, keep exact bibliography/citation consistency, contain no unresolved references or overfull boxes, build deterministically, embed fonts, use vector-only figures, pass all-page visual inspection, provide a complete manifest, and rebuild byte-identically from a clean extraction.
