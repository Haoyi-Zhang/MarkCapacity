# TOPLAS manuscript

Date: 2026-09-26

The public tree contains one identified, line-numbered ACM review manuscript, one scientific source, one bibliography, and a reproducible artifact with separate scientific and package-integrity entry points.

## Scientific content

The paper contains eight regular scientific sections, 52 formal statements with 52 explicit proofs, four native vector figures, nine tables, 68 scholarly bibliography records, and 99 single-key sentence-local citations. The central result classifies exact message feasibility by the operational quotient and source-indexed constraint hypergraph. Directed preservation, randomized/list recovery, coordinated products, complexity, compactness, recognition, and insertion remain within the stated theoretical scope.

The executable evidence is split deliberately. `artifact/run-tests.sh` is a self-contained standard-library scientific entry point with 56 scientific tests passing and deterministic output-hash checks. `artifact/run-package-checks.sh` is the separate full-project integrity entry point with 8 package-integrity tests passing; it requires the sibling paper tree and Poppler's `pdfinfo` and `pdftotext`. `artifact/run-all-checks.sh` runs all 64 checks in a complete checkout.

Every required source row must be present. Missing access or preservation rows are malformed inputs and raise `ValueError`; explicitly supplied empty rows are valid constraints that make every nonempty exact alphabet infeasible. Empty support is outside the support-capacity proposition. Capacity 0 records the absence of a scheme and is not an implementable empty alphabet; capacity 1 is a one-message scheme with zero selected bits.

## Author plan

`paper/author-plan.json` contains six positions. The known records are Haoyi Zhang, Huaijin Ran, and Xunzhu Tang; positions 4--6 are blank. Huaijin Ran is provisionally recorded as corresponding author. Final identities, order and corresponding authorship remain to be confirmed.

## Reproducibility and release state

The manuscript is exactly 48 pages in `manuscript,screen,review` mode, including references and end matter. All public figures are vector graphics. Two isolated PDF builds are byte-identical; the 56-test scientific suite and 8-test package suite pass; PDF preflight and all-page visual inspection pass. A deterministic candidate archive passed manifest verification, clean extraction, both entry points, scientific-output hash verification, and a byte-identical 48-page source rebuild.

CURRENT_GATE: FINAL_REPAIRED_INTERNAL_PACKAGE_WITH_AUTHOR_COMPLETION_AND_EXTERNAL_REVIEW_PENDING

SUBMISSION_POLICY_STATUS: HOLD

The remaining work is external: finalize all six authors and metadata, obtain each author's approval, resolve conflicts and prior-version disclosures, prepare the cover letter, check the live TOPLAS portal, and obtain a genuinely independent artifact-only review.
