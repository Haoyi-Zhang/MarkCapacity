# Paper source

`main.tex` is the canonical identified ACM source. Its declared class options are `acmsmall,screen`, and `build.sh` uses XeLaTeX. Page counts and line-number claims in dated audit records describe their respective compiled PDFs, not a guarantee about a newly built source.

The source contains three known ACM author records—Haoyi Zhang, Huaijin Ran, and Xunzhu Tang—and reserves three title-block line heights for the planned six-author paper without inventing names or metadata. See `author-plan.json` and `SUBMISSION-CHECKLIST.md` before any external action.

The manuscript contains eight scientific sections, 52 formal statements with 52 proofs, four native vector figures, nine tables, 68 scholarly bibliography records, and 99 single-key sentence-local citations. No inline scientific appendix or core supplement is used.

Executable evidence is reported separately: `artifact/run-tests.sh` schedules 71 scientific tests (65 retained plus six current regressions) and compares isolated reruns against the retained finite results. `artifact/run-package-checks.sh` contains 8 package-integrity checks requiring this paper tree, its dated audit records, current packaging metadata, and Poppler. The combined entry point schedules 79 checks; its retained baseline is 73. Historical host/build records are not measurements of the current source. `artifact/current-package-metadata.json` binds the existing 50-page `acmsmall,screen` PDF and scheduled counts, not a new build or all-page visual review. `current-statement-locations.json` records current source locations; the dated statement audit and bibliography/claim ledgers retain their historical page references.

Build from a clean directory with:

```sh
./build.sh
```

The supplied `acmart.cls` and `ACM-Reference-Format.bst` are unmodified. The source does not load `geometry`, set manual margins, alter the base font size, or compress the bibliography. No DOI, volume, issue, article number, rights statement, or publication date is asserted.

Matching unmodified `acmart.dtx`/`acmart.ins` and the complete original release
source snapshot are included; copyright, maintenance and LPPL notices remain
intact. `ACM-SOURCE-NOTICE.md` records the source authority and exact class-byte
match. No class upgrade, relicensing or new paper build is implied.

`main.bbl` is retained as bibliography source and bound to the active inclusion,
exact current bytes and all 68 keys. `artifact/run-current-export-checks.sh`
adds six portable role regressions and a current-inventory validator to the
existing eight package checks, with no inventory/hash/mode or Poppler waiver.
The 50-page PDF and all scientific results remain unchanged.
