# TOPLAS format status

- Venue family: ACM Transactions on Programming Languages and Systems.
- Public package mode: identified `manuscript,screen,review` draft with line numbers.
- Class and bibliography style: supplied `acmart` 2.19 and ACM reference style, unmodified.
- Page geometry: controlled entirely by the class; no `geometry` package or manual text-block settings.
- Length: exactly 48 rendered pages under the project contract, including references and end matter.
- Appendix: none in the scientific manuscript.
- Publication metadata: no unassigned DOI, rights statement, volume, issue, article number, or publication date.

The package records one working review mode only. This does not settle the live journal anonymity policy. Before upload, the authors must inspect the current Manuscript Central instructions and create a compliant anonymous copy outside the frozen internal package if the live portal requires one.

The current PDF is not an accepted/TAPS production file. ACM production controls the final rights, bibliographic strip, DOI, accessibility checks, and publication metadata after acceptance.
