# ACM class source

The bundled `acmart.cls` remains unmodified, version 2.19 (2026-06-27).
`acmart.dtx` and `acmart.ins` are unmodified files from the CTAN-linked
maintainer repository's release tag `v2.19`, commit
`062edc8119be9067a346ce874281eab48b2c29a4`. An isolated Unicode-engine
docstrip extraction produces the bundled class byte-for-byte. This extraction
generates source only, not a new paper or PDF.

The complete original repository source snapshot is retained unchanged as
`acmart-source-v2.19.tar.gz`. Its source files, copyright and maintenance notices
are retained, including the ACM copyright and LPPL declaration in `acmart.dtx`.
`ACM-LICENSE.txt` remains the supplied LPPL text. No new license is granted for
ACM files or the project's owned research source. The public-domain notice in
the unmodified bibliography style is also retained.

Source authority: [CTAN's 2.19 release announcement](https://ctan.org/ctan-ann/id/f991b965e3dbf134@hogwart),
[CTAN package/repository listing](https://ctan.org/pkg/acmart), and the
[immutable release source](https://github.com/borisveytsman/acmart/tree/062edc8119be9067a346ce874281eab48b2c29a4).
The latest upstream release is not substituted for this project's class.

`main.bbl` is the generated bibliography source consumed by the manuscript's
BibTeX inclusion, not a disposable processing log. Its exact bytes and 68 keys
are bound by current packaging metadata; arbitrary `.bbl`, `.aux`, and `.blg`
files are not permitted in the current export. This local source role does not
assert current TAPS upload policy or publication acceptance.
